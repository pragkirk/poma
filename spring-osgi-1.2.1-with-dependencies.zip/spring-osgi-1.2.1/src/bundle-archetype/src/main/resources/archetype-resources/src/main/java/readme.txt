Public package normally containing interfaces or other classes that can be exposed/shared with other bundles.
By default this package is exported by the bundle.