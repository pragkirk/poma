Internal (private) package that contains classes internal to this bundle. Thus, the content of this package is not exported and cannot be used
by other bundles.